# 荔园文学社投稿审核系统

## 项目概述
同安实验中学学生文学社团——荔园文学社的文章投稿审核系统。支持超级管理员、审核员、投稿社员三类角色，实现社员投稿、审核员审校、管理员全管的完整业务流程。

## 角色与权限

| 角色 | 权限 |
|------|------|
| 超级管理员 (super_admin) | 用户管理（增删改查、启停、设角色、重置密码）、查看全部投稿与审核情况 |
| 审核员 (reviewer) | 查看待审核队列、阅读稿件、通过/驳回并填写审核意见 |
| 投稿社员 (member) | 提交投稿、查看"我的投稿"列表及审核状态与意见 |

## 视觉设计规范

### 色彩系统
- **主色（墨绿）**: `#2f4a37` — 用于主按钮、导航栏、强调文字
- **深墨绿**: `#1e3327` — 用于深色背景、标题栏、footer
- **底色（宣纸米白）**: `#f6f2e8` — 页面背景
- **点缀色（暖金）**: `#b8893f` — 次要强调、链接 hover、状态标记
- **正文墨色**: `#2c2c2c` — 正文文字
- **次要文字**: `#6b6b6b` — 辅助说明文字

### 字体
- **标题与正文**: Noto Serif SC（衬线宋体气质），fallback: "Songti SC", "SimSun", serif
- **整体气质**: 书卷气、克制、有编辑感，避免 SaaS 圆角卡片风

### 布局与间距
- 内容最大宽度：960px（正文阅读友好宽度）
- 页面内边距：水平 24px，垂直 32px
- 卡片/区块：无圆角或极微圆角（2px），细线边框
- 行间距：正文 1.75，标题 1.3

### 组件风格
- 按钮：矩形，无圆角或 2px 圆角，墨绿底白字 / 白底墨绿边框
- 输入框：底部细线或全边框，focus 时暖金边框
- 表格：细线表头，行分隔线，无斑马纹
- 徽章图片：圆形，用于登录页、顶部导航

## 技术架构

### 后端
- NestJS + Drizzle ORM + PostgreSQL
- 认证：JWT（bcrypt 哈希密码）
- 权限：角色守卫（Role Guard）

### 前端
- React 19 + TypeScript + Tailwind CSS
- React Router DOM v6
- 状态管理：React Context（认证状态）
- 图标：lucide-react

### 数据库表
- `users`：用户表（id, username, password_hash, role, real_name, status, created_at, updated_at）
- `submissions`：投稿表（id, title, genre, content, author_id, status, review_comment, reviewer_id, reviewed_at, created_at, updated_at）

### API 设计
- POST `/api/auth/login` — 登录
- GET `/api/auth/me` — 当前用户信息
- GET `/api/users` — 用户列表（管理员）
- POST `/api/users` — 创建用户（管理员）
- PATCH `/api/users/:id` — 更新用户（管理员）
- PATCH `/api/users/:id/password` — 重置密码（管理员）
- POST `/api/submissions` — 提交投稿
- GET `/api/submissions` — 投稿列表（按角色过滤）
- GET `/api/submissions/:id` — 投稿详情
- PATCH `/api/submissions/:id/review` — 审核（审核员）

## 部署
- 标准 Linux 服务器，Node.js 22+ + PostgreSQL
- Nginx 反向代理
- 系统初始化自动创建超级管理员和默认审核员账户
