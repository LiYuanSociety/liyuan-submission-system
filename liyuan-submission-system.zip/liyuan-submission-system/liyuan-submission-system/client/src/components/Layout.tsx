import { Outlet, NavLink, Navigate, useNavigate } from 'react-router-dom';
import { LogOut, User, FileText, Users, CheckSquare } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import badgeUrl from '@/assets/liyuan-badge.png';
import type { UserRole } from '@shared/api.interface';
import { Image } from '@client/src/components/ui/image';

interface MenuItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const menuConfig: Record<UserRole, MenuItem[]> = {
  member: [
    { path: '/submit', label: '提交投稿', icon: <FileText size={16} /> },
    { path: '/my-submissions', label: '我的投稿', icon: <FileText size={16} /> },
  ],
  reviewer: [
    { path: '/review-queue', label: '待审核队列', icon: <CheckSquare size={16} /> },
    { path: '/all-submissions', label: '全部稿件', icon: <FileText size={16} /> },
  ],
  super_admin: [
    { path: '/user-manage', label: '用户管理', icon: <Users size={16} /> },
    { path: '/all-submissions', label: '全部稿件', icon: <FileText size={16} /> },
  ],
};

const Layout = () => {
  const { user, isLoading, logout } = useAuth();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <span className="text-muted-foreground">加载中...</span>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  const menuItems = menuConfig[user.role] || [];

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Top Navigation */}
      <header
        className="text-primary-foreground border-b border-sidebar-border"
        style={{ backgroundColor: 'hsl(140 27% 16%)' }}
      >
        <div className="lw-container flex items-center justify-between h-16 gap-4">
          {/* Left: Badge + Title */}
          <div className="flex items-center gap-3">
            <Image
              src={badgeUrl}
              alt="荔园文学社徽章"
              className="w-10 h-10 rounded-full object-cover border border-sidebar-border"
            />
            <span
              className="text-lg font-semibold tracking-wide"
              style={{ fontFamily: 'var(--font-serif)' }}
            >
              荔园文学社
            </span>
          </div>

          {/* Right: Nav + User + Logout */}
          <div className="flex items-center gap-2 md:gap-6 flex-wrap">
            {/* Navigation Menu */}
            <nav className="flex items-center gap-1 flex-wrap">
              {menuItems.map((item: MenuItem) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    cn(
                      'flex items-center gap-1.5 px-3 py-1.5 text-sm transition-colors',
                      'hover:text-accent',
                      isActive ? 'text-accent' : 'text-primary-foreground/80'
                    )
                  }
                >
                  {item.icon}
                  <span>{item.label}</span>
                </NavLink>
              ))}
            </nav>

            {/* Divider */}
            <div className="hidden md:block w-px h-6 bg-sidebar-border" />

            {/* User Info & Logout */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 text-sm text-primary-foreground/80">
                <User size={14} />
                <span className="hidden sm:inline">{user.realName}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-primary-foreground/80 hover:text-accent hover:bg-transparent h-auto px-2"
              >
                <LogOut size={14} />
                <span className="hidden sm:inline">退出</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">
        <div className="lw-container py-8">
          <Outlet />
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border">
        <div className="lw-container py-4 text-center text-xs text-muted-foreground">
          荔园文学社 © 2024 同安实验中学
        </div>
      </footer>
    </div>
  );
};

export default Layout;
