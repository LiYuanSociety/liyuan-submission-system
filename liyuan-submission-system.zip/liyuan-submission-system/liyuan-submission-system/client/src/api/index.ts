import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';
import { logger } from '@lark-apaas/client-toolkit/logger';
import type {
  LoginRequest,
  LoginResponse,
  LWUser,
  CreateUserRequest,
  UpdateUserRequest,
  ResetPasswordRequest,
  UserListResponse,
  CreateSubmissionRequest,
  ReviewSubmissionRequest,
  SubmissionListResponse,
  Submission,
  UserRole,
  UserStatus,
  SubmissionStatus,
  SubmissionGenre,
} from '@shared/api.interface';

export async function login(req: LoginRequest): Promise<LoginResponse> {
  try {
    const response = await axiosForBackend.post('/api/auth/login', req);
    return response.data;
  } catch (error) {
    logger.error('登录失败', error);
    throw error;
  }
}

export async function getCurrentUser(): Promise<LWUser> {
  const response = await axiosForBackend.get('/api/auth/me');
  return response.data;
}

export async function getUserList(params: {
  page?: number;
  pageSize?: number;
  role?: UserRole;
  status?: UserStatus;
  keyword?: string;
}): Promise<UserListResponse> {
  const response = await axiosForBackend.get('/api/users', { params });
  return response.data;
}

export async function createUser(req: CreateUserRequest): Promise<LWUser> {
  const response = await axiosForBackend.post('/api/users', req);
  return response.data;
}

export async function updateUser(
  id: string,
  req: UpdateUserRequest,
): Promise<LWUser> {
  const response = await axiosForBackend.patch(`/api/users/${id}`, req);
  return response.data;
}

export async function resetUserPassword(
  id: string,
  req: ResetPasswordRequest,
): Promise<void> {
  await axiosForBackend.patch(`/api/users/${id}/password`, req);
}

export async function createSubmission(
  req: CreateSubmissionRequest,
): Promise<Submission> {
  const response = await axiosForBackend.post('/api/submissions', req);
  return response.data;
}

export async function getSubmissionList(params: {
  page?: number;
  pageSize?: number;
  status?: SubmissionStatus;
  genre?: SubmissionGenre;
}): Promise<SubmissionListResponse> {
  const response = await axiosForBackend.get('/api/submissions', { params });
  return response.data;
}

export async function getSubmission(id: string): Promise<Submission> {
  const response = await axiosForBackend.get(`/api/submissions/${id}`);
  return response.data;
}

export async function reviewSubmission(
  id: string,
  req: ReviewSubmissionRequest,
): Promise<Submission> {
  const response = await axiosForBackend.patch(
    `/api/submissions/${id}/review`,
    req,
  );
  return response.data;
}
