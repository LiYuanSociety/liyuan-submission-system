import React from 'react';
import { Route, Routes, Navigate } from 'react-router-dom';

import Layout from './components/Layout';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import LoginPage from './pages/LoginPage/LoginPage';
import SubmitPage from './pages/SubmitPage/SubmitPage';
import MySubmissionsPage from './pages/MySubmissionsPage/MySubmissionsPage';
import ReviewQueuePage from './pages/ReviewQueuePage/ReviewQueuePage';
import UserManagePage from './pages/UserManagePage/UserManagePage';
import AllSubmissionsPage from './pages/AllSubmissionsPage/AllSubmissionsPage';
import SubmissionDetailPage from './pages/SubmissionDetailPage/SubmissionDetailPage';
import NotFound from './pages/NotFound/NotFound';

const HomeRedirect = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  switch (user.role) {
    case 'super_admin':
      return <Navigate to="/all-submissions" replace />;
    case 'reviewer':
      return <Navigate to="/review-queue" replace />;
    case 'member':
    default:
      return <Navigate to="/my-submissions" replace />;
  }
};

const RoutesComponent = () => {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<Layout />}>
          <Route index element={<HomeRedirect />} />
          <Route path="submit" element={<SubmitPage />} />
          <Route path="my-submissions" element={<MySubmissionsPage />} />
          <Route path="submissions/:id" element={<SubmissionDetailPage />} />
          <Route path="review-queue" element={<ReviewQueuePage />} />
          <Route path="all-submissions" element={<AllSubmissionsPage />} />
          <Route path="user-manage" element={<UserManagePage />} />
        </Route>
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AuthProvider>
  );
};

export default RoutesComponent;
