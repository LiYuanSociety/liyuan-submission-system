import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { createSubmission } from '@/api/index';
import type { SubmissionGenre } from '@shared/api.interface';

const GENRE_OPTIONS: { value: SubmissionGenre; label: string }[] = [
  { value: 'prose', label: '散文' },
  { value: 'poetry', label: '诗歌' },
  { value: 'novel', label: '小说' },
  { value: 'review', label: '评论' },
];

const SubmitPage: React.FC = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [genre, setGenre] = useState<SubmissionGenre | ''>('');
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [titleError, setTitleError] = useState('');
  const [genreError, setGenreError] = useState('');
  const [contentError, setContentError] = useState('');

  const validate = (): boolean => {
    let valid = true;
    setTitleError('');
    setGenreError('');
    setContentError('');

    if (!title.trim()) {
      setTitleError('请输入标题');
      valid = false;
    }
    if (!genre) {
      setGenreError('请选择体裁');
      valid = false;
    }
    if (!content.trim()) {
      setContentError('请输入正文内容');
      valid = false;
    }
    return valid;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!validate()) return;

    setSubmitting(true);
    try {
      await createSubmission({
        title: title.trim(),
        genre: genre as SubmissionGenre,
        content: content.trim(),
      });
      setSuccess(true);
      setTimeout(() => {
        navigate('/my-submissions');
      }, 2000);
    } catch (err) {
      logger.error('投稿提交失败', err);
      setErrorMsg('提交失败，请稍后重试');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="lw-container py-10">
        <header className="mb-8 text-center">
          <h1 className="font-serif text-3xl font-semibold text-primary tracking-wide">
            投稿
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            填写您的作品信息提交审核
          </p>
          <div className="lw-divider mx-auto mt-6 w-24" />
        </header>

        {success ? (
          <div className="mx-auto max-w-xl rounded-sm border border-border bg-card p-8 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M20 6 9 17l-5-5" />
              </svg>
            </div>
            <h2 className="font-serif text-xl font-medium text-foreground">
              投稿成功
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              您的投稿已提交，等待审核中
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              即将跳转到我的投稿页面…
            </p>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="mx-auto max-w-xl space-y-6 rounded-sm border border-border bg-card p-8"
          >
            <div className="space-y-2">
              <Label htmlFor="title" className="text-foreground">
                标题 <span className="text-destructive">*</span>
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="请输入作品标题"
                className={titleError ? 'border-destructive' : ''}
                disabled={submitting}
              />
              {titleError && (
                <p className="text-xs text-destructive">{titleError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="genre" className="text-foreground">
                体裁 <span className="text-destructive">*</span>
              </Label>
              <Select
                value={genre}
                onValueChange={(val) => setGenre(val as SubmissionGenre)}
                disabled={submitting}
              >
                <SelectTrigger
                  id="genre"
                  className={genreError ? 'border-destructive w-full' : 'w-full'}
                >
                  <SelectValue placeholder="请选择体裁" />
                </SelectTrigger>
                <SelectContent>
                  {GENRE_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {genreError && (
                <p className="text-xs text-destructive">{genreError}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="content" className="text-foreground">
                正文 <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="content"
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="请输入作品正文内容…"
                className={contentError ? 'border-destructive' : ''}
                style={{ minHeight: '400px', lineHeight: '1.75' }}
                disabled={submitting}
              />
              {contentError && (
                <p className="text-xs text-destructive">{contentError}</p>
              )}
            </div>

            {errorMsg && (
              <div className="rounded-sm border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
                {errorMsg}
              </div>
            )}

            <div className="pt-2">
              <Button
                type="submit"
                disabled={submitting}
                className="w-full rounded-sm bg-primary text-primary-foreground hover:bg-primary-dark"
                style={{ borderRadius: '2px' }}
              >
                {submitting ? '提交中...' : '提交投稿'}
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

export default SubmitPage;
