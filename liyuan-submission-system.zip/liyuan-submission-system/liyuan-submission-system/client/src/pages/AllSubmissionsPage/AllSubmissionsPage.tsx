import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Search } from 'lucide-react';
import { getSubmissionList } from '@/api/index';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from '@/components/ui/table';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
} from '@/components/ui/pagination';
import type {
  Submission,
  SubmissionStatus,
  SubmissionGenre,
} from '@shared/api.interface';

const STATUS_MAP: Record<string, string> = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

const GENRE_MAP: Record<string, string> = {
  prose: '散文',
  poetry: '诗歌',
  novel: '小说',
  review: '评论',
};

const statusBadgeVariant = (status: string): 'default' | 'destructive' | 'secondary' => {
  if (status === 'approved') return 'default';
  if (status === 'rejected') return 'destructive';
  return 'secondary';
};

const AllSubmissionsPage: React.FC = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<Submission[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [genreFilter, setGenreFilter] = useState<string>('');
  const [keyword, setKeyword] = useState('');
  const [searchInput, setSearchInput] = useState('');

  const fetchList = useCallback(async (
    p: number,
    status: SubmissionStatus | undefined,
    genre: SubmissionGenre | undefined,
  ) => {
    setLoading(true);
    try {
      const res = await getSubmissionList({
        page: p,
        pageSize,
        status,
        genre,
      });
      // 前端关键词过滤（标题或作者）
      const kw = keyword.trim();
      const filtered = kw
        ? res.items.filter(
            (item: Submission) =>
              item.title.includes(kw) ||
              (item.authorName && item.authorName.includes(kw)),
          )
        : res.items;
      setItems(filtered);
      setTotal(kw ? filtered.length : res.total);
    } catch (error) {
      logger.error('获取稿件列表失败', error);
    } finally {
      setLoading(false);
    }
  }, [pageSize, keyword]);

  useEffect(() => {
    const status = statusFilter ? (statusFilter as SubmissionStatus) : undefined;
    const genre = genreFilter ? (genreFilter as SubmissionGenre) : undefined;
    void fetchList(page, status, genre);
  }, [fetchList, page, statusFilter, genreFilter]);

  const handleSearch = () => {
    setKeyword(searchInput);
    setPage(1);
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="lw-container py-8">
      <div className="mb-6 border-b border-border pb-4">
        <h1 className="text-2xl font-semibold text-primary">全部稿件</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          共 <span className="font-medium text-accent">{total}</span> 篇稿件
        </p>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="w-[140px]">
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-full rounded-sm">
              <SelectValue placeholder="全部状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">全部状态</SelectItem>
              <SelectItem value="pending">待审核</SelectItem>
              <SelectItem value="approved">已通过</SelectItem>
              <SelectItem value="rejected">已驳回</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="w-[120px]">
          <Select value={genreFilter} onValueChange={(v) => { setGenreFilter(v); setPage(1); }}>
            <SelectTrigger className="w-full rounded-sm">
              <SelectValue placeholder="全部体裁" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">全部体裁</SelectItem>
              <SelectItem value="prose">散文</SelectItem>
              <SelectItem value="poetry">诗歌</SelectItem>
              <SelectItem value="novel">小说</SelectItem>
              <SelectItem value="review">评论</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-1 min-w-[200px] gap-2">
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleSearch(); }}
            placeholder="搜索标题或作者..."
            className="rounded-sm"
          />
          <Button variant="outline" size="sm" className="rounded-sm" onClick={handleSearch}>
            <Search className="size-3.5" />
            搜索
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center text-muted-foreground">加载中...</div>
      ) : items.length === 0 ? (
        <div className="py-20 text-center text-muted-foreground">
          <p>暂无稿件</p>
        </div>
      ) : (
        <>
          <div className="overflow-hidden rounded-sm border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead className="w-[28%]">标题</TableHead>
                  <TableHead>作者</TableHead>
                  <TableHead>体裁</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>审核员</TableHead>
                  <TableHead>提交时间</TableHead>
                  <TableHead>审核时间</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item: Submission) => (
                  <TableRow
                    key={item.id}
                    className="cursor-pointer hover:bg-secondary/30"
                    onClick={() => navigate(`/submissions/${item.id}`)}
                  >
                    <TableCell className="font-medium text-primary hover:underline">
                      {item.title}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.authorName || '—'}
                    </TableCell>
                    <TableCell>{GENRE_MAP[item.genre] || item.genre}</TableCell>
                    <TableCell>
                      <Badge
                        variant={statusBadgeVariant(item.status)}
                        className="rounded-sm"
                      >
                        {STATUS_MAP[item.status] || item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.reviewerName || '—'}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(item.createdAt).toLocaleString('zh-CN', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {item.reviewedAt
                        ? new Date(item.reviewedAt).toLocaleString('zh-CN', {
                            year: 'numeric',
                            month: '2-digit',
                            day: '2-digit',
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : '—'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="mt-6">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                      className={page === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((p) => Math.abs(p - page) <= 2 || p === 1 || p === totalPages)
                    .map((p, idx, arr) => (
                      <React.Fragment key={p}>
                        {idx > 0 && p - arr[idx - 1] > 1 && (
                          <PaginationItem>
                            <span className="px-2 text-muted-foreground">…</span>
                          </PaginationItem>
                        )}
                        <PaginationItem>
                          <PaginationLink
                            isActive={p === page}
                            onClick={() => setPage(p)}
                            className="cursor-pointer rounded-sm"
                          >
                            {p}
                          </PaginationLink>
                        </PaginationItem>
                      </React.Fragment>
                    ))}
                  <PaginationItem>
                    <PaginationNext
                      onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
                      className={page === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default AllSubmissionsPage;
