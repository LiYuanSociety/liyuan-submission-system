import { useState, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import badgeUrl from '@/assets/liyuan-badge.png';
import { Image } from '@client/src/components/ui/image';

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('请输入用户名和密码');
      return;
    }

    setIsSubmitting(true);
    try {
      await login(username.trim(), password);
      navigate('/', { replace: true });
    } catch (err: unknown) {
      const message =
        err && typeof err === 'object' && 'response' in err
          ? (err as { response?: { data?: { message?: string } } }).response?.data
              ?.message || '用户名或密码错误'
          : '用户名或密码错误';
      setError(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6 bg-background"
      style={{ fontFamily: 'var(--font-serif)' }}
    >
      <div className="w-full max-w-sm">
        {/* Login Card */}
        <div className="bg-card text-card-foreground border border-border shadow-md p-8 rounded-[2px]">
          {/* Badge + Title */}
          <div className="flex flex-col items-center mb-8">
            <Image
              src={badgeUrl}
              alt="荔园文学社徽章"
              className="w-[120px] h-[120px] rounded-full object-cover border-2 border-accent/30 mb-4"
            />
            <h1 className="text-2xl font-semibold text-primary tracking-wider">
              荔园文学社
            </h1>
            <p className="text-sm text-muted-foreground mt-1">投稿审核系统</p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <label
                htmlFor="username"
                className="text-sm font-medium text-foreground"
              >
                用户名
              </label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="请输入用户名"
                autoComplete="username"
                disabled={isSubmitting}
                className="rounded-[2px]"
              />
            </div>

            <div className="space-y-2">
              <label
                htmlFor="password"
                className="text-sm font-medium text-foreground"
              >
                密码
              </label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="请输入密码"
                autoComplete="current-password"
                disabled={isSubmitting}
                className="rounded-[2px]"
              />
            </div>

            {error && (
              <p className="text-sm text-destructive text-center">{error}</p>
            )}

            <Button
              type="submit"
              variant="default"
              size="default"
              disabled={isSubmitting}
              className="w-full rounded-[2px]"
            >
              {isSubmitting ? '登录中...' : '登 录'}
            </Button>
          </form>
        </div>

        {/* Bottom hint */}
        <p className="text-xs text-muted-foreground text-center mt-4">
          由超级管理员统一分配账号，不开放自助注册
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
