import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { ArrowLeft, FileText, Calendar, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { getSubmission } from '@/api/index';
import type { Submission, SubmissionStatus } from '@shared/api.interface';

const GENRE_LABEL: Record<string, string> = {
  prose: '散文',
  poetry: '诗歌',
  novel: '小说',
  review: '评论',
};

const STATUS_LABEL: Record<SubmissionStatus, string> = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

const statusBadgeVariant = (
  status: SubmissionStatus,
): 'default' | 'secondary' | 'destructive' => {
  switch (status) {
    case 'approved':
      return 'default';
    case 'rejected':
      return 'destructive';
    case 'pending':
    default:
      return 'secondary';
  }
};

const formatDate = (iso: string): string => {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${y}-${m}-${day} ${hh}:${mm}`;
};

const SubmissionDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [submission, setSubmission] = useState<Submission | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!id) return;
    setLoading(true);
    setErrorMsg('');
    getSubmission(id)
      .then((data) => {
        setSubmission(data);
      })
      .catch((err) => {
        logger.error('获取投稿详情失败', err);
        setErrorMsg('加载失败，请稍后重试');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [id]);

  return (
    <div className="min-h-screen bg-background">
      <div className="lw-container py-10">
        {/* Back button */}
        <Button
          variant="ghost"
          onClick={() => navigate(-1)}
          className="mb-6 rounded-sm text-muted-foreground hover:text-primary"
          style={{ borderRadius: '2px' }}
        >
          <ArrowLeft size={16} />
          返回
        </Button>

        {loading ? (
          <div className="rounded-sm border border-border bg-card p-12 text-center text-muted-foreground">
            加载中...
          </div>
        ) : errorMsg ? (
          <div className="rounded-sm border border-destructive/30 bg-destructive/10 p-6 text-center text-destructive">
            {errorMsg}
          </div>
        ) : submission ? (
          <article className="mx-auto max-w-3xl">
            {/* Header meta */}
            <header className="mb-6 border-b border-border pb-6">
              <div className="mb-3 flex items-center gap-3">
                <Badge
                  variant={statusBadgeVariant(submission.status)}
                  className="rounded-sm"
                  style={
                    submission.status === 'pending'
                      ? {
                          backgroundColor: 'hsl(40 49% 48%)',
                          color: 'hsl(45 33% 96%)',
                          border: 'none',
                          borderRadius: '2px',
                        }
                      : { borderRadius: '2px' }
                  }
                >
                  {STATUS_LABEL[submission.status]}
                </Badge>
                <span className="text-sm text-muted-foreground">
                  {GENRE_LABEL[submission.genre] || submission.genre}
                </span>
              </div>
              <h1 className="font-serif text-3xl font-semibold leading-tight text-foreground">
                {submission.title}
              </h1>
              <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
                <div className="flex items-center gap-1.5">
                  <User size={14} />
                  <span>作者：{submission.authorName || '—'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Calendar size={14} />
                  <span>提交时间：{formatDate(submission.createdAt)}</span>
                </div>
              </div>
            </header>

            {/* Content body */}
            <section
              className="rounded-sm border border-border bg-card p-8 font-serif leading-[1.75] text-foreground"
              style={{ lineHeight: '1.75' }}
            >
              <div className="whitespace-pre-wrap text-base">
                {submission.content}
              </div>
            </section>

            {/* Review comment */}
            {submission.status !== 'pending' && (
              <section className="mt-8">
                <h2 className="mb-3 flex items-center gap-2 font-serif text-lg font-medium text-foreground">
                  <FileText size={18} className="text-accent" />
                  审核意见
                </h2>
                <div className="text-sm text-muted-foreground">
                  审核员：
                  <span className="text-foreground">
                    {submission.reviewerName || '—'}
                  </span>
                  <span className="mx-2">·</span>
                  审核时间：
                  <span className="text-foreground">
                    {submission.reviewedAt
                      ? formatDate(submission.reviewedAt)
                      : '—'}
                  </span>
                </div>
                <div
                  className="mt-3 border-l-[3px] border-accent bg-card/80 p-5 pl-5 font-serif leading-[1.75]"
                  style={{
                    borderLeftColor: 'hsl(40 49% 48%)',
                    backgroundColor: 'hsl(45 33% 96%)',
                  }}
                >
                  <p className="whitespace-pre-wrap text-foreground">
                    {submission.reviewComment || '无审核意见'}
                  </p>
                </div>
              </section>
            )}
          </article>
        ) : null}
      </div>
    </div>
  );
};

export default SubmissionDetailPage;
