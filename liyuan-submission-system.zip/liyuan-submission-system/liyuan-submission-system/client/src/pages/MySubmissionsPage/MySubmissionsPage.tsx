import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { getSubmissionList } from '@/api/index';
import type {
  Submission,
  SubmissionStatus,
  SubmissionGenre,
} from '@shared/api.interface';

const STATUS_OPTIONS: { value: SubmissionStatus | 'all'; label: string }[] = [
  { value: 'all', label: '全部' },
  { value: 'pending', label: '待审核' },
  { value: 'approved', label: '已通过' },
  { value: 'rejected', label: '已驳回' },
];

const GENRE_OPTIONS: { value: SubmissionGenre | 'all'; label: string }[] = [
  { value: 'all', label: '全部体裁' },
  { value: 'prose', label: '散文' },
  { value: 'poetry', label: '诗歌' },
  { value: 'novel', label: '小说' },
  { value: 'review', label: '评论' },
];

const GENRE_LABEL: Record<SubmissionGenre, string> = {
  prose: '散文',
  poetry: '诗歌',
  novel: '小说',
  review: '评论',
};

const STATUS_LABEL: Record<SubmissionStatus, string> = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

const statusBadgeVariant = (
  status: SubmissionStatus,
): 'default' | 'secondary' | 'destructive' => {
  switch (status) {
    case 'approved':
      return 'default';
    case 'rejected':
      return 'destructive';
    case 'pending':
    default:
      return 'secondary';
  }
};

const formatDate = (iso: string): string => {
  const d = new Date(iso);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  return `${y}-${m}-${day} ${hh}:${mm}`;
};

const MySubmissionsPage: React.FC = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<Submission[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [statusFilter, setStatusFilter] = useState<SubmissionStatus | 'all'>(
    'all',
  );
  const [genreFilter, setGenreFilter] = useState<SubmissionGenre | 'all'>(
    'all',
  );
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const fetchList = useCallback(async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      const params: {
        page: number;
        pageSize: number;
        status?: SubmissionStatus;
        genre?: SubmissionGenre;
      } = { page, pageSize };
      if (statusFilter !== 'all') params.status = statusFilter;
      if (genreFilter !== 'all') params.genre = genreFilter;
      const res = await getSubmissionList(params);
      setItems(res.items);
      setTotal(res.total);
    } catch (err) {
      logger.error('获取投稿列表失败', err);
      setErrorMsg('加载失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  }, [page, pageSize, statusFilter, genreFilter]);

  useEffect(() => {
    void fetchList();
  }, [fetchList]);

  const handleStatusChange = (val: string) => {
    setStatusFilter(val as SubmissionStatus | 'all');
    setPage(1);
  };

  const handleGenreChange = (val: string) => {
    setGenreFilter(val as SubmissionGenre | 'all');
    setPage(1);
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="min-h-screen bg-background">
      <div className="lw-container py-10">
        <header className="mb-6">
          <h1 className="font-serif text-3xl font-semibold text-primary tracking-wide">
            我的投稿
          </h1>
          <div className="lw-divider mt-4 w-24" />
        </header>

        {/* Filter bar */}
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-sm border border-border bg-card p-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">状态：</span>
            <Select value={statusFilter} onValueChange={handleStatusChange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">体裁：</span>
            <Select value={genreFilter} onValueChange={handleGenreChange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {GENRE_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="ml-auto text-sm text-muted-foreground">
            共 {total} 篇
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 rounded-sm border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">
            {errorMsg}
          </div>
        )}

        {/* Table */}
        {loading ? (
          <div className="rounded-sm border border-border bg-card p-12 text-center text-muted-foreground">
            加载中...
          </div>
        ) : items.length === 0 ? (
          <div className="rounded-sm border border-border bg-card p-16 text-center">
            <FileText className="mx-auto mb-4 text-muted-foreground/50" size={48} />
            <p className="text-muted-foreground">暂无投稿</p>
            <Button
              variant="default"
              className="mt-6 rounded-sm"
              style={{ borderRadius: '2px' }}
              onClick={() => navigate('/submit')}
            >
              去投稿
            </Button>
          </div>
        ) : (
          <>
            <div className="overflow-hidden rounded-sm border border-border bg-card">
              <table className="w-full text-left text-sm">
                <thead className="border-b border-border bg-secondary/50">
                  <tr>
                    <th className="px-4 py-3 font-medium text-foreground">
                      标题
                    </th>
                    <th className="w-24 px-4 py-3 font-medium text-foreground">
                      体裁
                    </th>
                    <th className="w-24 px-4 py-3 font-medium text-foreground">
                      状态
                    </th>
                    <th className="w-40 px-4 py-3 font-medium text-foreground">
                      提交时间
                    </th>
                    <th className="w-20 px-4 py-3 text-right font-medium text-foreground">
                      操作
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item) => (
                    <tr
                      key={item.id}
                      className="border-b border-border/60 last:border-b-0 hover:bg-secondary/30"
                    >
                      <td className="px-4 py-3">
                        <button
                          type="button"
                          onClick={() =>
                            navigate(`/submissions/${item.id}`)
                          }
                          className="text-left text-foreground hover:text-primary hover:underline"
                        >
                          {item.title}
                        </button>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">
                        {GENRE_LABEL[item.genre]}
                      </td>
                      <td className="px-4 py-3">
                        <Badge
                          variant={statusBadgeVariant(item.status)}
                          className="rounded-sm"
                          style={
                            item.status === 'pending'
                              ? {
                                  backgroundColor: 'hsl(40 49% 48%)',
                                  color: 'hsl(45 33% 96%)',
                                  border: 'none',
                                  borderRadius: '2px',
                                }
                              : { borderRadius: '2px' }
                          }
                        >
                          {STATUS_LABEL[item.status]}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-muted-foreground">
                        {formatDate(item.createdAt)}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          type="button"
                          onClick={() =>
                            navigate(`/submissions/${item.id}`)
                          }
                          className="text-sm text-primary hover:underline"
                        >
                          查看
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
              <div>
                第 {page} / {totalPages} 页
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page <= 1 || loading}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  className="rounded-sm"
                  style={{ borderRadius: '2px' }}
                >
                  <ChevronLeft size={16} />
                  上一页
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page >= totalPages || loading}
                  onClick={() => setPage((p) => p + 1)}
                  className="rounded-sm"
                  style={{ borderRadius: '2px' }}
                >
                  下一页
                  <ChevronRight size={16} />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default MySubmissionsPage;
