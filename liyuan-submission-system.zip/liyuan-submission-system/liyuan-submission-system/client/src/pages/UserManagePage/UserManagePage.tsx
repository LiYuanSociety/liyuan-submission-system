import React, { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Search, UserPlus, Edit, Key, Power } from 'lucide-react';
import {
  getUserList,
  createUser,
  updateUser,
  resetUserPassword,
} from '@/api/index';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from '@/components/ui/table';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
} from '@/components/ui/pagination';
import type { LWUser, UserRole, UserStatus } from '@shared/api.interface';

const ROLE_MAP: Record<string, string> = {
  super_admin: '超级管理员',
  reviewer: '审核员',
  member: '投稿社员',
};

const UserManagePage: React.FC = () => {
  const [items, setItems] = useState<LWUser[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [roleFilter, setRoleFilter] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [keyword, setKeyword] = useState('');
  const [searchInput, setSearchInput] = useState('');

  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<LWUser | null>(null);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    realName: '',
    role: 'member' as UserRole,
  });
  const [formError, setFormError] = useState('');

  const [resetDialogOpen, setResetDialogOpen] = useState(false);
  const [resetUser, setResetUser] = useState<LWUser | null>(null);
  const [newPassword, setNewPassword] = useState('');

  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [confirmUser, setConfirmUser] = useState<LWUser | null>(null);
  const [confirmAction, setConfirmAction] = useState<'enable' | 'disable'>('disable');

  const [submitting, setSubmitting] = useState(false);
  const [tipMsg, setTipMsg] = useState('');

  const showTip = (msg: string) => {
    setTipMsg(msg);
    window.setTimeout(() => setTipMsg(''), 2000);
  };

  const fetchList = useCallback(async (
    p: number,
    role: UserRole | undefined,
    status: UserStatus | undefined,
    kw: string,
  ) => {
    setLoading(true);
    try {
      const res = await getUserList({
        page: p,
        pageSize,
        role,
        status,
        keyword: kw || undefined,
      });
      setItems(res.items);
      setTotal(res.total);
    } catch (error) {
      logger.error('获取用户列表失败', error);
    } finally {
      setLoading(false);
    }
  }, [pageSize]);

  useEffect(() => {
    const role = roleFilter ? (roleFilter as UserRole) : undefined;
    const status = statusFilter ? (statusFilter as UserStatus) : undefined;
    void fetchList(page, role, status, keyword);
  }, [fetchList, page, roleFilter, statusFilter, keyword]);

  const handleSearch = () => {
    setKeyword(searchInput.trim());
    setPage(1);
  };

  const openAddUser = () => {
    setEditingUser(null);
    setFormData({ username: '', password: '', realName: '', role: 'member' });
    setFormError('');
    setUserDialogOpen(true);
  };

  const openEditUser = (user: LWUser) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      password: '',
      realName: user.realName,
      role: user.role,
    });
    setFormError('');
    setUserDialogOpen(true);
  };

  const handleUserSubmit = async () => {
    setFormError('');
    if (!editingUser) {
      if (!formData.username.trim()) {
        setFormError('请输入用户名');
        return;
      }
      if (!formData.password) {
        setFormError('请输入密码');
        return;
      }
    }
    if (!formData.realName.trim()) {
      setFormError('请输入真实姓名');
      return;
    }

    setSubmitting(true);
    try {
      if (editingUser) {
        await updateUser(editingUser.id, {
          realName: formData.realName.trim(),
          role: formData.role,
        });
        showTip('用户信息已更新');
      } else {
        await createUser({
          username: formData.username.trim(),
          password: formData.password,
          realName: formData.realName.trim(),
          role: formData.role,
        });
        showTip('用户创建成功');
      }
      setUserDialogOpen(false);
      const role = roleFilter ? (roleFilter as UserRole) : undefined;
      const status = statusFilter ? (statusFilter as UserStatus) : undefined;
      void fetchList(page, role, status, keyword);
    } catch (error) {
      logger.error('用户操作失败', error);
      setFormError('操作失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const openResetPassword = (user: LWUser) => {
    setResetUser(user);
    setNewPassword('');
    setResetDialogOpen(true);
  };

  const handleResetPassword = async () => {
    if (!resetUser) return;
    if (!newPassword) {
      showTip('请输入新密码');
      return;
    }
    setSubmitting(true);
    try {
      await resetUserPassword(resetUser.id, { password: newPassword });
      showTip('密码重置成功');
      setResetDialogOpen(false);
    } catch (error) {
      logger.error('重置密码失败', error);
      showTip('重置失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const openToggleStatus = (user: LWUser) => {
    setConfirmUser(user);
    setConfirmAction(user.status === 'active' ? 'disable' : 'enable');
    setConfirmDialogOpen(true);
  };

  const handleToggleStatus = async () => {
    if (!confirmUser) return;
    const newStatus: UserStatus = confirmAction === 'disable' ? 'disabled' : 'active';
    setSubmitting(true);
    try {
      await updateUser(confirmUser.id, { status: newStatus });
      showTip(confirmAction === 'disable' ? '已停用用户' : '已启用用户');
      setConfirmDialogOpen(false);
      const role = roleFilter ? (roleFilter as UserRole) : undefined;
      const status = statusFilter ? (statusFilter as UserStatus) : undefined;
      void fetchList(page, role, status, keyword);
    } catch (error) {
      logger.error('更新用户状态失败', error);
      showTip('操作失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="lw-container py-8">
      <div className="mb-6 flex items-end justify-between border-b border-border pb-4">
        <div>
          <h1 className="text-2xl font-semibold text-primary">用户管理</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            共 <span className="font-medium text-accent">{total}</span> 位用户
          </p>
        </div>
        <Button
          variant="default"
          size="sm"
          className="rounded-sm"
          onClick={openAddUser}
        >
          <UserPlus className="size-3.5" />
          添加用户
        </Button>
      </div>

      <div className="mb-4 flex flex-wrap items-center gap-3">
        <div className="w-[140px]">
          <Select value={roleFilter} onValueChange={(v) => { setRoleFilter(v); setPage(1); }}>
            <SelectTrigger className="w-full rounded-sm">
              <SelectValue placeholder="全部角色" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">全部角色</SelectItem>
              <SelectItem value="member">投稿社员</SelectItem>
              <SelectItem value="reviewer">审核员</SelectItem>
              <SelectItem value="super_admin">超级管理员</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="w-[120px]">
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setPage(1); }}>
            <SelectTrigger className="w-full rounded-sm">
              <SelectValue placeholder="全部状态" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">全部状态</SelectItem>
              <SelectItem value="active">启用</SelectItem>
              <SelectItem value="disabled">停用</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-1 min-w-[200px] gap-2">
          <Input
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleSearch(); }}
            placeholder="搜索用户名或姓名..."
            className="rounded-sm"
          />
          <Button variant="outline" size="sm" className="rounded-sm" onClick={handleSearch}>
            <Search className="size-3.5" />
            搜索
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center text-muted-foreground">加载中...</div>
      ) : items.length === 0 ? (
        <div className="py-20 text-center text-muted-foreground">
          <p>暂无用户</p>
        </div>
      ) : (
        <>
          <div className="overflow-hidden rounded-sm border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead className="w-[18%]">用户名</TableHead>
                  <TableHead>姓名</TableHead>
                  <TableHead>角色</TableHead>
                  <TableHead>状态</TableHead>
                  <TableHead>创建时间</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((user: LWUser) => (
                  <TableRow key={user.id} className="hover:bg-secondary/30">
                    <TableCell className="font-medium">{user.username}</TableCell>
                    <TableCell>{user.realName}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {ROLE_MAP[user.role] || user.role}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={user.status === 'active' ? 'default' : 'secondary'}
                        className="rounded-sm"
                      >
                        {user.status === 'active' ? '启用' : '停用'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {new Date(user.createdAt).toLocaleDateString('zh-CN', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                      })}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="rounded-sm text-primary hover:bg-primary/10"
                          onClick={() => openEditUser(user)}
                        >
                          <Edit className="size-3.5" />
                          编辑
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="rounded-sm text-accent hover:bg-accent/10"
                          onClick={() => openResetPassword(user)}
                        >
                          <Key className="size-3.5" />
                          重置密码
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className={`rounded-sm ${
                            user.status === 'active'
                              ? 'text-destructive hover:bg-destructive/10'
                              : 'text-primary hover:bg-primary/10'
                          }`}
                          onClick={() => openToggleStatus(user)}
                        >
                          <Power className="size-3.5" />
                          {user.status === 'active' ? '停用' : '启用'}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="mt-6">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                      className={page === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((p) => Math.abs(p - page) <= 2 || p === 1 || p === totalPages)
                    .map((p, idx, arr) => (
                      <React.Fragment key={p}>
                        {idx > 0 && p - arr[idx - 1] > 1 && (
                          <PaginationItem>
                            <span className="px-2 text-muted-foreground">…</span>
                          </PaginationItem>
                        )}
                        <PaginationItem>
                          <PaginationLink
                            isActive={p === page}
                            onClick={() => setPage(p)}
                            className="cursor-pointer rounded-sm"
                          >
                            {p}
                          </PaginationLink>
                        </PaginationItem>
                      </React.Fragment>
                    ))}
                  <PaginationItem>
                    <PaginationNext
                      onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
                      className={page === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </>
      )}

      {/* 用户表单弹窗 */}
      <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
        <DialogContent className="max-w-md rounded-sm">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">
              {editingUser ? '编辑用户' : '新增用户'}
            </DialogTitle>
            <DialogDescription className="sr-only">
              用户信息表单
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="username">用户名</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) =>
                  setFormData({ ...formData, username: e.target.value })
                }
                disabled={!!editingUser}
                placeholder="请输入用户名"
                className="rounded-sm"
              />
            </div>

            {!editingUser && (
              <div className="space-y-1.5">
                <Label htmlFor="password">密码</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                  placeholder="请输入密码"
                  className="rounded-sm"
                />
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="realName">真实姓名</Label>
              <Input
                id="realName"
                value={formData.realName}
                onChange={(e) =>
                  setFormData({ ...formData, realName: e.target.value })
                }
                placeholder="请输入真实姓名"
                className="rounded-sm"
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="role">角色</Label>
              <Select
                value={formData.role}
                onValueChange={(v) =>
                  setFormData({ ...formData, role: v as UserRole })
                }
              >
                <SelectTrigger className="w-full rounded-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="member">投稿社员</SelectItem>
                  <SelectItem value="reviewer">审核员</SelectItem>
                  <SelectItem value="super_admin">超级管理员</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formError && (
              <p className="text-sm text-destructive">{formError}</p>
            )}
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-sm"
              onClick={() => setUserDialogOpen(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <Button
              variant="default"
              size="sm"
              className="rounded-sm"
              onClick={() => void handleUserSubmit()}
              disabled={submitting}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 重置密码弹窗 */}
      <Dialog open={resetDialogOpen} onOpenChange={setResetDialogOpen}>
        <DialogContent className="max-w-md rounded-sm">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">重置密码</DialogTitle>
            <DialogDescription className="sr-only">
              重置用户密码
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              为用户 <span className="font-medium text-foreground">{resetUser?.username}</span> 重置密码
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="newPassword">新密码</Label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="请输入新密码"
                className="rounded-sm"
              />
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-sm"
              onClick={() => setResetDialogOpen(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <Button
              variant="default"
              size="sm"
              className="rounded-sm"
              onClick={() => void handleResetPassword()}
              disabled={submitting}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 启用/停用确认弹窗 */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent className="max-w-sm rounded-sm">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">
              {confirmAction === 'disable' ? '确认停用' : '确认启用'}
            </DialogTitle>
            <DialogDescription className="sr-only">
              操作确认
            </DialogDescription>
          </DialogHeader>

          <div className="py-2 text-sm text-muted-foreground">
            确定要{confirmAction === 'disable' ? '停用' : '启用'}用户{' '}
            <span className="font-medium text-foreground">{confirmUser?.username}</span> 吗？
          </div>

          <DialogFooter className="gap-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-sm"
              onClick={() => setConfirmDialogOpen(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <Button
              variant={confirmAction === 'disable' ? 'destructive' : 'default'}
              size="sm"
              className="rounded-sm"
              onClick={() => void handleToggleStatus()}
              disabled={submitting}
            >
              确认
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {tipMsg && (
        <div className="fixed bottom-8 left-1/2 z-[100] -translate-x-1/2 rounded-sm border border-border bg-card px-4 py-2 text-sm shadow-md">
          {tipMsg}
        </div>
      )}
    </div>
  );
};

export default UserManagePage;
