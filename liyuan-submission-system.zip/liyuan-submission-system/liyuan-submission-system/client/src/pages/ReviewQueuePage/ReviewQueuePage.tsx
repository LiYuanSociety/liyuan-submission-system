import React, { useState, useEffect, useCallback } from 'react';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Eye } from 'lucide-react';
import { getSubmissionList, reviewSubmission } from '@/api/index';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Table,
  TableHeader,
  TableBody,
  TableHead,
  TableRow,
  TableCell,
} from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationPrevious,
  PaginationNext,
} from '@/components/ui/pagination';
import type { Submission } from '@shared/api.interface';

const GENRE_MAP: Record<string, string> = {
  prose: '散文',
  poetry: '诗歌',
  novel: '小说',
  review: '评论',
};

const ReviewQueuePage: React.FC = () => {
  const [items, setItems] = useState<Submission[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [loading, setLoading] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [currentSubmission, setCurrentSubmission] = useState<Submission | null>(null);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [tipMsg, setTipMsg] = useState('');

  const fetchList = useCallback(async (p: number) => {
    setLoading(true);
    try {
      const res = await getSubmissionList({
        page: p,
        pageSize,
        status: 'pending',
      });
      setItems(res.items);
      setTotal(res.total);
    } catch (error) {
      logger.error('获取待审核列表失败', error);
    } finally {
      setLoading(false);
    }
  }, [pageSize]);

  useEffect(() => {
    void fetchList(page);
  }, [fetchList, page]);

  const openReview = (sub: Submission) => {
    setCurrentSubmission(sub);
    setComment('');
    setReviewOpen(true);
  };

  const showTip = (msg: string) => {
    setTipMsg(msg);
    window.setTimeout(() => setTipMsg(''), 2000);
  };

  const handleReview = async (decision: 'approve' | 'reject') => {
    if (!currentSubmission) return;
    setSubmitting(true);
    try {
      await reviewSubmission(currentSubmission.id, { decision, comment });
      showTip(decision === 'approve' ? '已通过审核' : '已驳回');
      setReviewOpen(false);
      void fetchList(page);
    } catch (error) {
      logger.error('审核失败', error);
      showTip('操作失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <div className="lw-container py-8">
      <div className="mb-6 flex items-end justify-between border-b border-border pb-4">
        <div>
          <h1 className="text-2xl font-semibold text-primary">待审核投稿</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            共 <span className="font-medium text-accent">{total}</span> 篇待审核
          </p>
        </div>
      </div>

      {loading ? (
        <div className="py-16 text-center text-muted-foreground">加载中...</div>
      ) : items.length === 0 ? (
        <div className="py-20 text-center text-muted-foreground">
          <p>暂无待审核稿件</p>
        </div>
      ) : (
        <>
          <div className="overflow-hidden rounded-sm border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/40">
                  <TableHead className="w-[35%]">标题</TableHead>
                  <TableHead>作者</TableHead>
                  <TableHead>体裁</TableHead>
                  <TableHead>提交时间</TableHead>
                  <TableHead className="text-right">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item: Submission) => (
                  <TableRow
                    key={item.id}
                    className="hover:bg-secondary/30"
                  >
                    <TableCell className="font-medium">{item.title}</TableCell>
                    <TableCell className="text-muted-foreground">
                      {item.authorName || '—'}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="rounded-sm">
                        {GENRE_MAP[item.genre] || item.genre}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {new Date(item.createdAt).toLocaleString('zh-CN', {
                        year: 'numeric',
                        month: '2-digit',
                        day: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        className="rounded-sm"
                        onClick={() => openReview(item)}
                      >
                        <Eye className="mr-1 size-3.5" />
                        审核
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <div className="mt-6">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setPage((prev) => Math.max(1, prev - 1))}
                      className={page === 1 ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                  {Array.from({ length: totalPages }, (_, i) => i + 1)
                    .filter((p) => Math.abs(p - page) <= 2 || p === 1 || p === totalPages)
                    .map((p, idx, arr) => (
                      <React.Fragment key={p}>
                        {idx > 0 && p - arr[idx - 1] > 1 && (
                          <PaginationItem>
                            <span className="px-2 text-muted-foreground">…</span>
                          </PaginationItem>
                        )}
                        <PaginationItem>
                          <PaginationLink
                            isActive={p === page}
                            onClick={() => setPage(p)}
                            className="cursor-pointer rounded-sm"
                          >
                            {p}
                          </PaginationLink>
                        </PaginationItem>
                      </React.Fragment>
                    ))}
                  <PaginationItem>
                    <PaginationNext
                      onClick={() => setPage((prev) => Math.min(totalPages, prev + 1))}
                      className={page === totalPages ? 'pointer-events-none opacity-50' : 'cursor-pointer'}
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </>
      )}

      <Dialog open={reviewOpen} onOpenChange={setReviewOpen}>
        <DialogContent className="max-w-2xl rounded-sm">
          <DialogHeader>
            <DialogTitle className="text-xl text-primary">审核投稿</DialogTitle>
            <DialogDescription className="sr-only">
              查看投稿内容并进行审核
            </DialogDescription>
          </DialogHeader>

          {currentSubmission && (
            <div className="space-y-4">
              <div className="space-y-1 border-b border-border pb-3">
                <h2 className="text-lg font-medium">{currentSubmission.title}</h2>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <span>作者：{currentSubmission.authorName || '—'}</span>
                  <span className="text-border">|</span>
                  <span>体裁：{GENRE_MAP[currentSubmission.genre] || currentSubmission.genre}</span>
                </div>
              </div>

              <div
                className="max-h-[300px] overflow-y-auto rounded-sm border border-border bg-muted/20 p-4 text-[15px] leading-relaxed"
                style={{ whiteSpace: 'pre-wrap' }}
              >
                {currentSubmission.content}
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">审核意见</label>
                <Textarea
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  placeholder="请填写审核意见..."
                  className="min-h-[80px] rounded-sm"
                />
              </div>
            </div>
          )}

          <DialogFooter className="flex-row gap-2 sm:justify-between">
            <Button
              variant="outline"
              size="sm"
              className="rounded-sm"
              onClick={() => setReviewOpen(false)}
              disabled={submitting}
            >
              取消
            </Button>
            <div className="flex gap-2">
              <Button
                variant="default"
                size="sm"
                className="rounded-sm bg-primary text-primary-foreground"
                onClick={() => void handleReview('approve')}
                disabled={submitting}
              >
                通过
              </Button>
              <Button
                variant="destructive"
                size="sm"
                className="rounded-sm"
                onClick={() => void handleReview('reject')}
                disabled={submitting}
              >
                驳回
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {tipMsg && (
        <div className="fixed bottom-8 left-1/2 z-[100] -translate-x-1/2 rounded-sm border border-border bg-card px-4 py-2 text-sm shadow-md">
          {tipMsg}
        </div>
      )}
    </div>
  );
};

export default ReviewQueuePage;
