import { Injectable, Inject, Logger, OnModuleInit, ConflictException, NotFoundException } from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, desc, ilike, or } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';

import { lwUsers } from '@server/database/schema';
import type {
  LWUser,
  CreateUserRequest,
  UpdateUserRequest,
  UserListResponse,
  UserRole,
  UserStatus,
} from '@shared/api.interface';

interface FindAllParams {
  page: number;
  pageSize: number;
  role?: UserRole;
  status?: UserStatus;
  keyword?: string;
}

@Injectable()
export class UsersService implements OnModuleInit {
  private readonly logger = new Logger(UsersService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async onModuleInit(): Promise<void> {
    try {
      await this.ensureDefaultUsers();
    } catch (error) {
      this.logger.error('初始化默认用户失败', error);
    }
  }

  async ensureDefaultUsers(): Promise<void> {
    const defaults: Array<{
      username: string;
      password: string;
      realName: string;
      role: UserRole;
    }> = [
      {
        username: 'admin',
        password: 'admin123',
        realName: '超级管理员',
        role: 'super_admin',
      },
      {
        username: 'reviewer',
        password: 'reviewer123',
        realName: '默认审核员',
        role: 'reviewer',
      },
    ];

    for (const user of defaults) {
      const existing = await this.db
        .select({ id: lwUsers.id })
        .from(lwUsers)
        .where(eq(lwUsers.username, user.username));

      if (existing.length > 0) continue;

      const passwordHash = await bcrypt.hash(user.password, 10);
      await this.db.insert(lwUsers).values({
        username: user.username,
        passwordHash,
        realName: user.realName,
        role: user.role,
        status: 'active',
        isDefault: true,
      });
      this.logger.log(`已创建默认用户: ${user.username}`);
    }
  }

  async create(dto: CreateUserRequest): Promise<LWUser> {
    const existing = await this.db
      .select({ id: lwUsers.id })
      .from(lwUsers)
      .where(eq(lwUsers.username, dto.username));

    if (existing.length > 0) {
      throw new ConflictException('用户名已存在');
    }

    const passwordHash = await bcrypt.hash(dto.password, 10);
    const inserted = await this.db
      .insert(lwUsers)
      .values({
        username: dto.username,
        passwordHash,
        realName: dto.realName,
        role: dto.role,
        status: 'active',
        isDefault: false,
      })
      .returning({
        id: lwUsers.id,
        username: lwUsers.username,
        realName: lwUsers.realName,
        role: lwUsers.role,
        status: lwUsers.status,
        isDefault: lwUsers.isDefault,
        createdAt: lwUsers.createdAt,
      });

    return this.mapToLWUser(inserted[0]);
  }

  async findAll(params: FindAllParams): Promise<UserListResponse> {
    const { page, pageSize, role, status, keyword } = params;
    const offset = (page - 1) * pageSize;

    const conditions = [];
    if (role) conditions.push(eq(lwUsers.role, role));
    if (status) conditions.push(eq(lwUsers.status, status));
    if (keyword) {
      const likePattern = `%${keyword}%`;
      conditions.push(or(
        ilike(lwUsers.username, likePattern),
        ilike(lwUsers.realName, likePattern),
      ));
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [totalResult, rows] = await Promise.all([
      this.db
        .select({ count: count() })
        .from(lwUsers)
        .where(whereClause),
      this.db
        .select({
          id: lwUsers.id,
          username: lwUsers.username,
          realName: lwUsers.realName,
          role: lwUsers.role,
          status: lwUsers.status,
          isDefault: lwUsers.isDefault,
          createdAt: lwUsers.createdAt,
        })
        .from(lwUsers)
        .where(whereClause)
        .orderBy(desc(lwUsers.createdAt))
        .limit(pageSize)
        .offset(offset),
    ]);

    const total = totalResult[0]?.count ?? 0;

    return {
      items: rows.map(row => this.mapToLWUser(row)),
      total,
      page,
      pageSize,
    };
  }

  async findOne(id: string): Promise<LWUser> {
    const rows = await this.db
      .select({
        id: lwUsers.id,
        username: lwUsers.username,
        realName: lwUsers.realName,
        role: lwUsers.role,
        status: lwUsers.status,
        isDefault: lwUsers.isDefault,
        createdAt: lwUsers.createdAt,
      })
      .from(lwUsers)
      .where(eq(lwUsers.id, id));

    if (rows.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return this.mapToLWUser(rows[0]);
  }

  async findByUsername(username: string): Promise<typeof lwUsers.$inferSelect | null> {
    const rows = await this.db
      .select()
      .from(lwUsers)
      .where(eq(lwUsers.username, username));
    return rows[0] ?? null;
  }

  async update(id: string, dto: UpdateUserRequest): Promise<LWUser> {
    const patch: Partial<typeof lwUsers.$inferInsert> = {};
    if (dto.realName !== undefined) patch.realName = dto.realName;
    if (dto.role !== undefined) patch.role = dto.role;
    if (dto.status !== undefined) patch.status = dto.status;

    if (Object.keys(patch).length === 0) {
      return this.findOne(id);
    }

    const updated = await this.db
      .update(lwUsers)
      .set(patch)
      .where(eq(lwUsers.id, id))
      .returning({
        id: lwUsers.id,
        username: lwUsers.username,
        realName: lwUsers.realName,
        role: lwUsers.role,
        status: lwUsers.status,
        isDefault: lwUsers.isDefault,
        createdAt: lwUsers.createdAt,
      });

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }

    return this.mapToLWUser(updated[0]);
  }

  async resetPassword(id: string, password: string): Promise<void> {
    const passwordHash = await bcrypt.hash(password, 10);
    const updated = await this.db
      .update(lwUsers)
      .set({ passwordHash })
      .where(eq(lwUsers.id, id))
      .returning({ id: lwUsers.id });

    if (updated.length === 0) {
      throw new NotFoundException('用户不存在');
    }
  }

  private mapToLWUser(row: {
    id: string;
    username: string;
    realName: string;
    role: string;
    status: string;
    isDefault: boolean;
    createdAt: Date;
  }): LWUser {
    return {
      id: row.id,
      username: row.username,
      realName: row.realName,
      role: row.role as UserRole,
      status: row.status as UserStatus,
      isDefault: row.isDefault,
      createdAt: row.createdAt.toISOString(),
    };
  }
}
