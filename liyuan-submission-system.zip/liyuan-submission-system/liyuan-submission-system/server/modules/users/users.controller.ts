import {
  Controller,
  Get,
  Post,
  Patch,
  Body,
  Param,
  Query,
  UseGuards,
  ParseIntPipe,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';

import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

import type {
  LWUser,
  CreateUserRequest,
  UpdateUserRequest,
  ResetPasswordRequest,
  UserListResponse,
  UserRole,
  UserStatus,
} from '@shared/api.interface';

@Controller('api/users')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('super_admin')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  async findAll(
    @Query('page', new ParseIntPipe({ optional: true })) page?: number,
    @Query('pageSize', new ParseIntPipe({ optional: true })) pageSize?: number,
    @Query('role') role?: UserRole,
    @Query('status') status?: UserStatus,
    @Query('keyword') keyword?: string,
  ): Promise<UserListResponse> {
    const resolvedPage = Math.max(1, page ?? 1);
    const resolvedPageSize = Math.min(100, Math.max(1, pageSize ?? 20));
    return this.usersService.findAll({
      page: resolvedPage,
      pageSize: resolvedPageSize,
      role,
      status,
      keyword,
    });
  }

  @Post()
  async create(@Body() dto: CreateUserRequest): Promise<LWUser> {
    return this.usersService.create(dto);
  }

  @Get(':id')
  async findOne(@Param('id') id: string): Promise<LWUser> {
    return this.usersService.findOne(id);
  }

  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateUserRequest,
  ): Promise<LWUser> {
    return this.usersService.update(id, dto);
  }

  @Patch(':id/password')
  @HttpCode(HttpStatus.NO_CONTENT)
  async resetPassword(
    @Param('id') id: string,
    @Body() dto: ResetPasswordRequest,
  ): Promise<void> {
    await this.usersService.resetPassword(id, dto.password);
  }
}
