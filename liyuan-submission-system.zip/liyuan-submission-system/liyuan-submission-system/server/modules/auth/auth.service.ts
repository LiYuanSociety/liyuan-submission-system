import { Inject, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { eq } from 'drizzle-orm';
import * as bcrypt from 'bcrypt';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { lwUsers } from '@server/database/schema';
import type { LWUser, UserRole } from '@shared/api.interface';

interface JwtPayload {
  userId: string;
  username: string;
  role: UserRole;
}

interface UserWithPassword {
  id: string;
  username: string;
  passwordHash: string;
  realName: string;
  role: UserRole;
  status: string;
  isDefault: boolean;
  createdAt: Date;
}

@Injectable()
export class AuthService {
  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
    private readonly jwtService: JwtService,
  ) {}

  async validateUser(username: string, password: string): Promise<LWUser> {
    const users = await this.db
      .select()
      .from(lwUsers)
      .where(eq(lwUsers.username, username))
      .limit(1);

    if (users.length === 0) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    const user = users[0] as UserWithPassword;

    if (user.status === 'disabled') {
      throw new UnauthorizedException('该账号已被禁用');
    }

    const passwordValid: boolean = await bcrypt.compare(
      password,
      user.passwordHash,
    );
    if (!passwordValid) {
      throw new UnauthorizedException('用户名或密码错误');
    }

    return this.toUserResponse(user);
  }

  async login(user: LWUser): Promise<{ token: string; user: LWUser }> {
    const payload: JwtPayload = {
      userId: user.id,
      username: user.username,
      role: user.role,
    };
    const token: string = await this.jwtService.signAsync(payload);
    return { token, user };
  }

  async findById(id: string): Promise<LWUser | null> {
    const users = await this.db
      .select()
      .from(lwUsers)
      .where(eq(lwUsers.id, id))
      .limit(1);

    if (users.length === 0) return null;
    return this.toUserResponse(users[0] as UserWithPassword);
  }

  private toUserResponse(user: UserWithPassword): LWUser {
    return {
      id: user.id,
      username: user.username,
      realName: user.realName,
      role: user.role as UserRole,
      status: user.status as 'active' | 'disabled',
      isDefault: user.isDefault,
      createdAt: user.createdAt.toISOString(),
    };
  }
}
