import {
  Controller,
  Get,
  Post,
  Patch,
  Body,
  Param,
  Query,
  Req,
  UseGuards,
  ParseIntPipe,
} from '@nestjs/common';
import type { Request } from 'express';

import { SubmissionsService } from './submissions.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';

import type {
  Submission,
  SubmissionStatus,
  SubmissionGenre,
  CreateSubmissionRequest,
  ReviewSubmissionRequest,
  SubmissionListResponse,
} from '@shared/api.interface';

@Controller('api/submissions')
@UseGuards(JwtAuthGuard, RolesGuard)
export class SubmissionsController {
  constructor(private readonly submissionsService: SubmissionsService) {}

  @Post()
  @Roles('member')
  async create(
    @Req() req: Request,
    @Body() dto: CreateSubmissionRequest,
  ): Promise<Submission> {
    const { userId } = req.user;
    return this.submissionsService.create(dto, userId);
  }

  @Get()
  async findAll(
    @Req() req: Request,
    @Query('page', new ParseIntPipe({ optional: true })) page?: number,
    @Query('pageSize', new ParseIntPipe({ optional: true })) pageSize?: number,
    @Query('status') status?: SubmissionStatus,
    @Query('genre') genre?: SubmissionGenre,
  ): Promise<SubmissionListResponse> {
    const { userId, role: userRole } = req.user;
    const resolvedPage = Math.max(1, page ?? 1);
    const resolvedPageSize = Math.min(100, Math.max(1, pageSize ?? 20));
    return this.submissionsService.list({
      page: resolvedPage,
      pageSize: resolvedPageSize,
      status,
      genre,
      userId,
      userRole,
    });
  }

  @Get(':id')
  async findOne(@Req() req: Request, @Param('id') id: string): Promise<Submission> {
    const { userId, role: userRole } = req.user;
    return this.submissionsService.findOne(id, userId, userRole);
  }

  @Patch(':id/review')
  @Roles('reviewer', 'super_admin')
  async review(
    @Req() req: Request,
    @Param('id') id: string,
    @Body() dto: ReviewSubmissionRequest,
  ): Promise<Submission> {
    const { userId, role: userRole } = req.user;
    return this.submissionsService.review(id, dto, userId, userRole);
  }
}
