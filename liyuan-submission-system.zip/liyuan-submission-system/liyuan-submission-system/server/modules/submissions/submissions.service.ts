import {
  Injectable,
  Inject,
  Logger,
  NotFoundException,
  ForbiddenException,
  BadRequestException,
} from '@nestjs/common';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { eq, and, count, desc, inArray } from 'drizzle-orm';

import { lwSubmissions, lwUsers } from '@server/database/schema';
import type {
  Submission,
  SubmissionStatus,
  SubmissionGenre,
  CreateSubmissionRequest,
  ReviewSubmissionRequest,
  SubmissionListResponse,
  UserRole,
} from '@shared/api.interface';

interface ListParams {
  page: number;
  pageSize: number;
  status?: SubmissionStatus;
  genre?: SubmissionGenre;
  userId: string;
  userRole: UserRole;
}

interface SubmissionRow {
  id: string;
  title: string;
  genre: string;
  content: string;
  authorId: string;
  status: string;
  reviewComment: string | null;
  reviewerId: string | null;
  reviewedAt: Date | null;
  createdAt: Date;
}

@Injectable()
export class SubmissionsService {
  private readonly logger = new Logger(SubmissionsService.name);

  constructor(@Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase) {}

  async create(dto: CreateSubmissionRequest, authorId: string): Promise<Submission> {
    const inserted = await this.db
      .insert(lwSubmissions)
      .values({
        title: dto.title,
        genre: dto.genre,
        content: dto.content,
        authorId,
        status: 'pending',
      })
      .returning();

    const author = await this.db
      .select({ realName: lwUsers.realName })
      .from(lwUsers)
      .where(eq(lwUsers.id, authorId))
      .limit(1);

    return this.toSubmission(inserted[0] as SubmissionRow, author[0]?.realName);
  }

  async list(params: ListParams): Promise<SubmissionListResponse> {
    const { page, pageSize, status, genre, userId, userRole } = params;

    const conditions = [];
    if (userRole === 'member') {
      conditions.push(eq(lwSubmissions.authorId, userId));
    }
    if (status) conditions.push(eq(lwSubmissions.status, status));
    if (genre) conditions.push(eq(lwSubmissions.genre, genre));

    const rows = await this.db
      .select()
      .from(lwSubmissions)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(lwSubmissions.createdAt))
      .limit(pageSize)
      .offset((page - 1) * pageSize);

    const countResult = await this.db
      .select({ count: count() })
      .from(lwSubmissions)
      .where(conditions.length > 0 ? and(...conditions) : undefined);

    const userIds = new Set<string>();
    for (const row of rows) {
      const r = row as SubmissionRow;
      userIds.add(r.authorId);
      if (r.reviewerId) userIds.add(r.reviewerId);
    }

    const userMap = new Map<string, string>();
    if (userIds.size > 0) {
      const users = await this.db
        .select({ id: lwUsers.id, realName: lwUsers.realName })
        .from(lwUsers)
        .where(inArray(lwUsers.id, Array.from(userIds)));
      for (const u of users) {
        userMap.set(u.id, u.realName);
      }
    }

    const items: Submission[] = rows.map((row) => {
      const r = row as SubmissionRow;
      return this.toSubmission(
        r,
        userMap.get(r.authorId),
        r.reviewerId ? userMap.get(r.reviewerId) : undefined,
      );
    });

    return {
      items,
      total: Number(countResult[0].count),
      page,
      pageSize,
    };
  }

  async findOne(id: string, userId: string, userRole: UserRole): Promise<Submission> {
    const rows = await this.db
      .select()
      .from(lwSubmissions)
      .where(eq(lwSubmissions.id, id))
      .limit(1);

    if (rows.length === 0) {
      throw new NotFoundException('投稿不存在');
    }

    const submission = rows[0] as SubmissionRow;

    if (userRole === 'member' && submission.authorId !== userId) {
      throw new ForbiddenException('无权查看他人投稿');
    }

    const userIds = [submission.authorId];
    if (submission.reviewerId) userIds.push(submission.reviewerId);

    const users = await this.db
      .select({ id: lwUsers.id, realName: lwUsers.realName })
      .from(lwUsers)
      .where(inArray(lwUsers.id, userIds));
    const userMap = new Map<string, string>();
    for (const u of users) {
      userMap.set(u.id, u.realName);
    }

    return this.toSubmission(
      submission,
      userMap.get(submission.authorId),
      submission.reviewerId ? userMap.get(submission.reviewerId) : undefined,
    );
  }

  async review(
    id: string,
    dto: ReviewSubmissionRequest,
    reviewerId: string,
    userRole: UserRole,
  ): Promise<Submission> {
    if (userRole !== 'reviewer' && userRole !== 'super_admin') {
      throw new ForbiddenException('无权审核投稿');
    }

    const existing = await this.db
      .select()
      .from(lwSubmissions)
      .where(eq(lwSubmissions.id, id))
      .limit(1);

    if (existing.length === 0) {
      throw new NotFoundException('投稿不存在');
    }

    if ((existing[0] as SubmissionRow).status !== 'pending') {
      throw new BadRequestException('只能审核待处理的投稿');
    }

    const newStatus: SubmissionStatus = dto.decision === 'approve' ? 'approved' : 'rejected';
    const now = new Date();

    await this.db
      .update(lwSubmissions)
      .set({
        status: newStatus,
        reviewComment: dto.comment,
        reviewerId,
        reviewedAt: now,
      })
      .where(eq(lwSubmissions.id, id));

    return this.findOne(id, reviewerId, userRole);
  }

  private toSubmission(
    row: SubmissionRow,
    authorName?: string,
    reviewerName?: string,
  ): Submission {
    return {
      id: row.id,
      title: row.title,
      genre: row.genre as SubmissionGenre,
      content: row.content,
      authorId: row.authorId,
      authorName,
      status: row.status as SubmissionStatus,
      reviewComment: row.reviewComment ?? undefined,
      reviewerId: row.reviewerId ?? undefined,
      reviewerName,
      reviewedAt: row.reviewedAt ? row.reviewedAt.toISOString() : undefined,
      createdAt: row.createdAt.toISOString(),
    };
  }
}
