export type UserRole = 'super_admin' | 'reviewer' | 'member';

export type UserStatus = 'active' | 'disabled';

export type SubmissionStatus = 'pending' | 'approved' | 'rejected';

export type SubmissionGenre = 'prose' | 'poetry' | 'novel' | 'review';

export interface LWUser {
  id: string;
  username: string;
  realName: string;
  role: UserRole;
  status: UserStatus;
  isDefault: boolean;
  createdAt: string;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: LWUser;
}

export interface CreateUserRequest {
  username: string;
  password: string;
  realName: string;
  role: UserRole;
}

export interface UpdateUserRequest {
  realName?: string;
  role?: UserRole;
  status?: UserStatus;
}

export interface ResetPasswordRequest {
  password: string;
}

export interface Submission {
  id: string;
  title: string;
  genre: SubmissionGenre;
  content: string;
  authorId: string;
  authorName?: string;
  status: SubmissionStatus;
  reviewComment?: string;
  reviewerId?: string;
  reviewerName?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface CreateSubmissionRequest {
  title: string;
  genre: SubmissionGenre;
  content: string;
}

export interface ReviewSubmissionRequest {
  decision: 'approve' | 'reject';
  comment: string;
}

export interface SubmissionListResponse {
  items: Submission[];
  total: number;
  page: number;
  pageSize: number;
}

export interface UserListResponse {
  items: LWUser[];
  total: number;
  page: number;
  pageSize: number;
}
