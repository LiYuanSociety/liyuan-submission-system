# 荔园文学社投稿审核系统 - 部署说明

## 系统概述

荔园文学社文章投稿审核系统，支持超级管理员、审核员、投稿社员三类角色，
实现社员投稿、审核员审校、管理员全管的完整业务流程。

- 后端：NestJS + Node.js 22+
- 前端：React 19 + Vite
- 数据库：PostgreSQL 14+
- 反向代理：Nginx

## 一、服务器环境要求

| 项目 | 要求 |
|------|------|
| 操作系统 | CentOS 7+ / Ubuntu 20.04+ / Debian 11+ |
| Node.js | 22.x 或更高 |
| PostgreSQL | 14.x 或更高 |
| Nginx | 1.18+ |
| 内存 | 最低 2GB，推荐 4GB+ |
| 磁盘 | 最低 20GB 可用空间 |

## 二、安装依赖

### 1. 安装 Node.js 22

```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
apt-get install -y nodejs

# CentOS/RHEL
curl -fsSL https://rpm.nodesource.com/setup_22.x | bash -
yum install -y nodejs

# 验证
node --version
npm --version
```

### 2. 安装 PostgreSQL

```bash
# Ubuntu/Debian
apt-get install -y postgresql postgresql-contrib

# CentOS/RHEL
yum install -y postgresql-server postgresql-contrib
postgresql-setup --initdb
systemctl enable postgresql
systemctl start postgresql

# 设置密码并创建数据库
su - postgres
psql -c "ALTER USER postgres PASSWORD 'your_password';"
psql -c "CREATE DATABASE liyuan_wenxue OWNER postgres;"
exit
```

### 3. 安装 Nginx

```bash
# Ubuntu/Debian
apt-get install -y nginx

# CentOS/RHEL
yum install -y nginx

systemctl enable nginx
systemctl start nginx
```

## 三、部署应用

### 1. 上传代码

将项目代码上传到服务器，例如 `/opt/liyuan-wenxue`：

```bash
mkdir -p /opt/liyuan-wenxue
cd /opt/liyuan-wenxue
# 上传代码后解压（或 git clone）
```

### 2. 安装依赖

```bash
cd /opt/liyuan-wenxue
npm install
```

### 3. 配置环境变量

在项目根目录创建 `.env` 文件：

```env
# 数据库配置
DB_HOST=localhost
DB_PORT=5432
DB_USER=postgres
DB_PASSWORD=your_password
DB_NAME=liyuan_wenxue

# 服务端口
SERVER_PORT=3000

# JWT 密钥（请修改为随机字符串）
JWT_SECRET=liyuan-wenxue-secret-key-change-me-2024
JWT_EXPIRES_IN=7d

# 运行环境
NODE_ENV=production
```

### 4. 初始化数据库表

首次部署需要创建数据库表。运行以下命令：

```bash
npm run build:server
```

然后在数据库中执行建表 SQL（以下为核心表结构）：

```sql
-- 用户表
CREATE TABLE IF NOT EXISTS lw_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username varchar(50) NOT NULL UNIQUE,
  password_hash varchar(255) NOT NULL,
  real_name varchar(100) NOT NULL,
  role varchar(20) NOT NULL DEFAULT 'member',
  status varchar(20) NOT NULL DEFAULT 'active',
  is_default boolean NOT NULL DEFAULT false,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 投稿表
CREATE TABLE IF NOT EXISTS lw_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title varchar(255) NOT NULL,
  genre varchar(20) NOT NULL,
  content text NOT NULL,
  author_id uuid NOT NULL REFERENCES lw_users(id),
  status varchar(20) NOT NULL DEFAULT 'pending',
  review_comment text,
  reviewer_id uuid REFERENCES lw_users(id),
  reviewed_at TIMESTAMP(3) WITH TIME ZONE,
  _created_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
  _updated_at TIMESTAMP(3) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 索引
CREATE INDEX IF NOT EXISTS idx_lw_users_username ON lw_users(username);
CREATE INDEX IF NOT EXISTS idx_lw_users_role ON lw_users(role);
CREATE INDEX IF NOT EXISTS idx_lw_users_status ON lw_users(status);
CREATE INDEX IF NOT EXISTS idx_lw_submissions_author_id ON lw_submissions(author_id);
CREATE INDEX IF NOT EXISTS idx_lw_submissions_status ON lw_submissions(status);
CREATE INDEX IF NOT EXISTS idx_lw_submissions_created_at ON lw_submissions(_created_at DESC);
```

执行方式：
```bash
psql -U postgres -d liyuan_wenxue -f path/to/schema.sql
```

### 5. 构建前端

```bash
npm run build:client
```

构建产物位于 `dist/client/` 目录。

### 6. 构建后端

```bash
npm run build:server
```

构建产物位于 `dist/server/` 目录。

## 四、启动后端服务

### 使用 systemd 管理服务（推荐）

创建服务文件 `/etc/systemd/system/liyuan-wenxue.service`：

```ini
[Unit]
Description=Liyuan Wenxue Submission System
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/liyuan-wenxue
Environment=NODE_ENV=production
Environment=SERVER_PORT=3000
Environment=DB_HOST=localhost
Environment=DB_PORT=5432
Environment=DB_USER=postgres
Environment=DB_PASSWORD=your_password
Environment=DB_NAME=liyuan_wenxue
Environment=JWT_SECRET=your_jwt_secret_here
ExecStart=/usr/bin/node dist/server/main.js
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=liyuan-wenxue

[Install]
WantedBy=multi-user.target
```

启动服务：

```bash
systemctl daemon-reload
systemctl enable liyuan-wenxue
systemctl start liyuan-wenxue

# 查看状态
systemctl status liyuan-wenxue

# 查看日志
journalctl -u liyuan-wenxue -f
```

## 五、配置 Nginx 反向代理

创建 Nginx 配置文件 `/etc/nginx/conf.d/liyuan-wenxue.conf`：

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # 前端静态文件
    location / {
        root /opt/liyuan-wenxue/dist/client;
        index index.html;
        try_files $uri $uri/ /index.html;

        # 静态资源缓存
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff2?)$ {
            expires 30d;
            add_header Cache-Control "public, immutable";
        }
    }

    # 后端 API 代理
    location /api/ {
        proxy_pass http://127.0.0.1:3000/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # 超时设置
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;

        # 缓冲区设置
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 4k;
    }

    # 文件上传大小限制
    client_max_body_size 10m;

    # Gzip 压缩
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_types text/plain text/css text/xml text/javascript application/json application/javascript application/xml+rss;
}
```

测试并重启 Nginx：

```bash
nginx -t
systemctl reload nginx
```

## 六、默认账户

系统首次启动时会自动创建以下默认账户：

### 超级管理员
- **用户名**: `admin`
- **密码**: `admin123`
- **角色**: 超级管理员

### 默认审核员
- **用户名**: `reviewer`
- **密码**: `reviewer123`
- **角色**: 审核员

> ⚠️ **重要**：首次登录后请立即修改默认密码！
> 超级管理员可以在"用户管理"页面重置任意用户的密码，
> 包括默认审核员账户的密码。

## 七、日常维护

### 查看运行日志

```bash
# 后端日志
journalctl -u liyuan-wenxue -f

# Nginx 访问日志
tail -f /var/log/nginx/access.log

# Nginx 错误日志
tail -f /var/log/nginx/error.log
```

### 重启服务

```bash
systemctl restart liyuan-wenxue
```

### 更新版本

```bash
cd /opt/liyuan-wenxue
# 拉取新代码
git pull  # 或上传新版本

# 安装新依赖（如有）
npm install

# 重新构建
npm run build:client
npm run build:server

# 重启服务
systemctl restart liyuan-wenxue
```

### 数据库备份

```bash
# 备份
pg_dump -U postgres liyuan_wenxue > /backup/liyuan_wenxue_$(date +%Y%m%d).sql

# 恢复
psql -U postgres liyuan_wenxue < /backup/liyuan_wenxue_YYYYMMDD.sql
```

建议配置定时任务（crontab）每日自动备份。

## 八、HTTPS 配置（推荐）

使用 Let's Encrypt 免费证书：

```bash
# 安装 certbot
apt-get install -y certbot python3-certbot-nginx

# 获取证书并自动配置
certbot --nginx -d your-domain.com
```

证书会自动续期，无需手动操作。

## 九、常见问题

### 1. 服务启动失败
- 检查端口 3000 是否被占用：`netstat -tlnp | grep 3000`
- 检查数据库连接配置是否正确
- 查看日志：`journalctl -u liyuan-wenxue -n 50`

### 2. 前端页面白屏
- 检查 Nginx 配置中 root 路径是否正确
- 检查 dist/client 目录是否存在 index.html
- 查看浏览器控制台报错信息

### 3. API 请求 404
- 确认后端服务是否正常运行
- 检查 Nginx proxy_pass 配置
- 确认请求路径以 /api/ 开头

### 4. 忘记管理员密码
可直接在数据库中重置密码哈希：

```sql
-- 先用 bcrypt 生成新密码哈希，或用临时账户
-- 更简单的方法：用 Node.js 生成
-- node -e "const bcrypt=require('bcrypt'); console.log(bcrypt.hashSync('new_password', 10));"
UPDATE lw_users SET password_hash = '<new_hash>' WHERE username = 'admin';
```
